package practica5;

public class Punto {
    public void muestra() {

    }
}
